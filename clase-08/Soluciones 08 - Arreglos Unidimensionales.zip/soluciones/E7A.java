
import java.util.Scanner;

public class E7A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        for (int t = 0; t < 3; t++) {
            int idx = 0;
            int menor = Integer.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                if (arr[i] < menor) {
                    menor = arr[i];
                    idx = i;
                }
            }
            System.out.println(menor);
            arr[idx] = Integer.MAX_VALUE;
        }

        sc.close();
    }
}