
import java.util.Scanner;

public class E5 {
    public static int[] leer_arreglo(int n, Scanner sc) {
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        return arr;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = leer_arreglo(n, sc);
        int[] orden = leer_arreglo(n, sc);

        for (int i = 0; i < n; i++) {
            System.out.println(arr[orden[i]]);
        }

        sc.close();
    }
}