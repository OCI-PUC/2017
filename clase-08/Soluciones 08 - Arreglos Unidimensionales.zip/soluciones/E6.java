
import java.util.Scanner;

public class E6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        boolean repetidos = false;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i] == arr[j]) {
                    repetidos = true;
                    break;
                }
            }
        }

        if (repetidos) {
            System.out.println("Hay numeros repetidos");
        } else {
            System.out.println("No hay numeros repetidos");
        }

        sc.close();
    }
}