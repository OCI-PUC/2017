
import java.util.Scanner;

public class E3 {

    public static boolean coprimo(int a, int b) {
        int min;
        if (a < b) {
            min = a;
        } else {
            min = b;
        }
        for (int d = 2; d <= min; d++) {
            if (a % d == 0 && b % d == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (!coprimo(arr[i], arr[j])) {
                    System.out.println("No es coprimo a pares. El par " + arr[i] + ", " + arr[j] + " no es coprimo");
                    return;
                }
            }
        }

        System.out.println("Coprimo a pares");
    }
}