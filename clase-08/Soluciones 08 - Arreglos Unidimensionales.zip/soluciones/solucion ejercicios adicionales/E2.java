
import java.util.Scanner;

public class E2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        int min = Integer.MAX_VALUE;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }

        int mcm = 1;
        for (int d = 2; d <= min; d++) {
            boolean divisor_comun = true;
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] % d != 0) {
                    divisor_comun = false;
                    break;
                }
            }
            if (divisor_comun) {
                mcm = d;
            }
        }

        if (mcm == 1) {
            System.out.println("Coprimo");
        } else {
            System.out.println("No es coprimo. Maximo común divisor: " + mcm);
        }

    }
}