
import java.util.Scanner;

public class E1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int m = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < n; i++) {
            int elem = arr[i];
            int counter = 0;
            for (int j = 0; j < n; j++) {
                if (arr[j] == arr[i]) {
                    counter += 1;
                }
            }
            if (counter == m) {
                System.out.println("El número " + elem + " se repite " + m + " veces");
                return;
            }
        }

        System.out.println("Ningún número se repite " + m + " veces");

    }
}