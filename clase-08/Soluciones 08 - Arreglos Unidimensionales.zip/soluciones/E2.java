
import java.util.Scanner;

public class E2 {

    public static int[] leer_arreglo(int n, Scanner sc) {
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        return arr;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n1 = sc.nextInt();
        int[] arr1 = leer_arreglo(n1, sc);
        int n2 = sc.nextInt();
        int[] arr2 = leer_arreglo(n2, sc);

        boolean iguales = true;
        if (n1 != n2) {
            iguales = false;
        } else {
            for (int i = 0; i < n1; i++) {
                if (arr1[i] != arr2[i]) {
                    iguales = false;
                    break;
                }
            }
        }

        if (iguales) {
            System.out.println("Las secuencias son iguales");
        } else {
            System.out.println("Las secuencias son distintas");
        }

        sc.close();
    }
}