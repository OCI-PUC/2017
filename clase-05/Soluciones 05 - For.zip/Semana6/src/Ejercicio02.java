import java.util.Scanner;

public class Ejercicio02 {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int anterior = Integer.MIN_VALUE;
		boolean ordenados = true;
		for (int i = 0; i < n; i++) {
			int actual = scan.nextInt();
			if (actual < anterior){
				ordenados = false;
			}
			anterior = actual;
			
		}
		
		if(ordenados){
			System.out.println("Ordenados");
		}
		else{
			System.out.println("Desordenados");
		}
		
		scan.close();
	}

}
