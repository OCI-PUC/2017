import java.util.Scanner;

public class Ejercicio01 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		
		//podr�a ser int si la respuesta es entero
		double suma = 0;
		for (int i = 0; i < n; i++) {
			int num = scan.nextInt();
			suma += num;
		}
		
		System.out.println(suma/n);
		
		scan.close();
	}

}
