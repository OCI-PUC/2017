import java.util.Scanner;

public class Ejercicio06 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		
		int resueltos = 0;
		
		for (int i = 0; i < n; i++) {
			int m = scan.nextInt();
			boolean correcto = true;
			
			for (int j = 0; j < m; j++) {
				int logrado = scan.nextInt();
				if(logrado != 1){
					correcto = false;
				}
			}
			
			if(correcto){
				resueltos++;
			}

		}
		
		System.out.println(resueltos);
		
		scan.close();

	}

}
