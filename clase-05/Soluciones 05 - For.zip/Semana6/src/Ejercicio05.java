import java.util.Scanner;

public class Ejercicio05 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int primero = 0;
		int segundo = 1;
		
		for (int i = 0; i < n; i++) {
			System.out.println(primero);
			int aux = segundo;
			segundo = primero + segundo;
			primero = aux;

		}
		
		scan.close();
	}

}
