import java.util.Scanner;

public class Ejercicio08_Inteligente {

	/*
	 * Nota importante:
	 * Se puede aprovechar la diferencia junto al modulo entre estos numeros para detectar el ganador,
	 * en vez de ponerse en todos los casos posibles, si no ser�an muchos condiciones de chequeo, una lata :'(
	 */
	
	public static void main(String[] args) {
		//Piedra = 1, Papel = 2, Tijera = 3.
		
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int ganadas1 = 0;
		int ganadas2 = 0;
		for (int i = 0; i < n; i++) {
			int jug1 = scan.nextInt();
			int jug2 = scan.nextInt();
			
			//Sumamos 3 para que la diferencia sea siempre positiva
			int dif = jug1 - jug2 + 3;
			
			//Jugador 1 gana
			if(dif % 3 == 1 ){
				ganadas1++;
			}
			//Jugador 2 gana
			else if(dif % 3 == 2){
				ganadas2++;
			}
			
			//Si no se mete en los anteriores significa que la diferencia es 0
			//esto quiere decir empate, ya que sacaron la misma jugada.
			
		}
		if(ganadas1 > ganadas2){
			System.out.println("Jugador 1");
		}
		else if(ganadas2 > ganadas1){
			System.out.println("Jugador 2");
		}
		else{
			System.out.println("Empate");
		}
		
		
		scan.close();

	}

}
