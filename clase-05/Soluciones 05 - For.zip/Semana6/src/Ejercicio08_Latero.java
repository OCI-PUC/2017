import java.util.Scanner;

public class Ejercicio08_Latero {

	/*
	 * Nota importante:
	 * Esta solucion es latera, hay que ponerse en todos los casos posibles, eso si es correcta :)
	 */
	
	public static void main(String[] args) {
		//Piedra = 1, Papel = 2, Tijera = 3.
		
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int ganadas1 = 0;
		int ganadas2 = 0;
		for (int i = 0; i < n; i++) {
			int jug1 = scan.nextInt();
			int jug2 = scan.nextInt();
			
			//Sacamos al tiro el caso de empate
			if(jug1 != jug2){
				if((jug1 == 2 && jug2 == 1) || (jug1 == 3 && jug2 == 2) || (jug1 == 1 && jug2 == 3)){
					ganadas1++;
				}
				//Basta hacerlo con un else, no es necesario chequear esto, pero lo dejo para que se entienda.
				else if((jug1 == 1 && jug2 == 2) || (jug1 == 2 && jug2 == 3) || (jug1 == 3 && jug2 == 1)){
					ganadas2++;
				}				
				
			}
				
			//Si no se mete en los anteriores significa que la diferencia es 0
			//esto quiere decir empate, ya que sacaron la misma jugada.
			
		}
		if(ganadas1 > ganadas2){
			System.out.println("Jugador 1");
		}
		else if(ganadas2 > ganadas1){
			System.out.println("Jugador 2");
		}
		else{
			System.out.println("Empate");
		}
		
		
		scan.close();
	}

}
