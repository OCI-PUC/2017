import java.util.Scanner;

public class Ejercicio07 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int m = scan.nextInt();
		
		for (int num = n; num <= m; num++) {
			boolean esPrimo = true;
			for (int i = 2; i < num; i++) {
				if(num % i == 0){
					esPrimo = false;
					break;
				}
			}
			
			if(esPrimo){
				System.out.println(num);
			}
			
		}
		
		scan.close();

	}

}
