import java.util.Scanner;

public class Ejercicio06 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int n = scan.nextInt();
		boolean primo = true;
		int contador = 2;
		
		while(contador < n){
			if(n%contador == 0){
				primo = false;
				break;
			}
			contador = contador + 1;
		}
		if(primo){
			System.out.println("Es primo");
		}
		else{
			System.out.println("No es primo");
		}
	}
}
