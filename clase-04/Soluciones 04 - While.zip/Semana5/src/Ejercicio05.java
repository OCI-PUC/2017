import java.util.Scanner;

public class Ejercicio05 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int n = scan.nextInt();
		int m = scan.nextInt();

		int suma_total = 0;
		int contador_iteracion = 0;
		
		while(contador_iteracion < n){
			int numero_linea = scan.nextInt();
			suma_total = suma_total + numero_linea;
			contador_iteracion = contador_iteracion + 1;
		}
		double promedio = suma_total/n;
		
		if(contador_iteracion != 0){
			if(promedio>m){
				System.out.println(-1);
			}
			else{
				System.out.println(promedio);

			}
		}
		
	}

}
