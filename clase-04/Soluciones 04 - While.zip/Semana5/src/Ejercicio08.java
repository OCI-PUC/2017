import java.util.Scanner;

public class Ejercicio08 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int n, valor;
    
    valor = scan.nextInt();

    int monedas20 = 0;
    int monedas50 = 0;
    int monedas100 = 0;
    
    int respuesta20 = -1;
    int respuesta50 = -1;
    int respuesta100 = -1;
    
    while (monedas20 <= valor / 20) {
      monedas50 = 0;
      while (monedas50 <= valor / 50) {
        monedas100 = 0;
        while (monedas100 <= valor / 100) {
          if (20 * monedas20 + 50 * monedas50 + 100 * monedas100 == valor) {
            // Buscamos si es menor a la cantidad actual
            if (respuesta20 == -1 || monedas20 + monedas50 + monedas100 < respuesta20 + respuesta50 + respuesta100) {
              respuesta20 = monedas20;
              respuesta50 = monedas50;
              respuesta100 = monedas100;
            }
          }
        
          monedas100 = monedas100 + 1;
        }
        monedas50 = monedas50 + 1;
      }
      monedas20 = monedas20 + 1;
    }
   
    if (respuesta20 == -1) {
      // No encontramos ninguna soluci�n
      System.out.println("No existe combinaci�n de billetes que sume " + valor);
    } else {
      System.out.println(respuesta20 + " de 20, " + respuesta50 + " de 50, " + respuesta100 + " de 100");
    }
    
    scan.close();

  }

}
