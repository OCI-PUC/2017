import java.util.Scanner;

public class Ejercicio04 {

	public static void main(String[] args){
		
		Scanner scan = new Scanner(System.in);
	
		int n = scan.nextInt();
		int contador_iteracion = 0;
		int minimo = 101;
		int maximo = 0;
				
		
		while(contador_iteracion < n){
			
			int numero_linea = scan.nextInt();
			
			if(numero_linea < minimo){
				minimo = numero_linea;
			}
			if(numero_linea > maximo){
				maximo = numero_linea;
			}
			contador_iteracion = contador_iteracion + 1;
		}
		
		if(n%2 == 0){
			System.out.println(maximo);
		}
		else
		{
			System.out.println(minimo);			
		}
	}
}
