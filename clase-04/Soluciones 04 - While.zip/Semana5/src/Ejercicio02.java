import java.util.Scanner;

public class Ejercicio02 {

	public static void main(String[] args) {

		
		Scanner scan = new Scanner(System.in);
		
		int n = scan.nextInt();
		int suma_total = 0;
		int contador_iteracion = 0;
		
		while(contador_iteracion < n){
			int numero_linea = scan.nextInt();
			suma_total = suma_total + numero_linea;
			contador_iteracion = contador_iteracion + 1;
		}
		if(contador_iteracion != 0){
			System.out.println(suma_total);
		}
		
	}

}
