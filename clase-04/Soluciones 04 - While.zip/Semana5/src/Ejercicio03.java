import java.util.Scanner;

public class Ejercicio03 {

	public static void main(String[] args) {

		
		Scanner scan = new Scanner(System.in);
		
		int n = scan.nextInt();
		int m = scan.nextInt();

		int multiplicacion_total = 1;
		int contador_iteracion = 0;
		
		while(contador_iteracion < n){
			int numero_linea = scan.nextInt();
			multiplicacion_total = multiplicacion_total*numero_linea;
			contador_iteracion++;
		}
		if(contador_iteracion != 0){
			if(multiplicacion_total>m){
				System.out.println(-1);
			}
			else{
				System.out.println(multiplicacion_total);

			}
		}
		
	}

}
