package operadores_booleanos;

import java.util.Scanner;

public class Ejercicio02 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);

    int a = scan.nextInt();
    int b = scan.nextInt();
    
    if ((a > 0 && b > 0) || (a < 0 && b < 0)) {
      System.out.println("El resultado será positivo");
    } else if ((a < 0 && b > 0) || (a > 0 && b < 0)) {
      System.out.println("El resultado será negativo");
    } else {
      System.out.println("Sin signo :3");
    }
    
  }

}
