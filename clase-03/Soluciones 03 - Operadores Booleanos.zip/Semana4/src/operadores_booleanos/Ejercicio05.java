package operadores_booleanos;

import java.util.Scanner;

public class Ejercicio05 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    int a = scan.nextInt();
    int b = scan.nextInt();
    int c = scan.nextInt();
    
    if ((b < a && a < c) || (c < a && a < b)) { 
      System.out.println(a + " está entre " + b + " y " + c);
    } else if (a == b || a == c) {
      System.out.println(a + " es igual a uno de los números");
    } else {
      System.out.println(a + " no está entre " + b + " y " + c);
    }

  }

}
