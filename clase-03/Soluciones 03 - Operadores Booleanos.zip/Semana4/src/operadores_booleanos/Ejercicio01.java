package operadores_booleanos;

import java.util.Scanner;

public class Ejercicio01 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);

    int a = scan.nextInt();
    int b = scan.nextInt();
    
    if ((a > 0 && b < 0) || (a < 0 && b > 0)) {
      System.out.println("Existe un valor negativo");
    } else if ((a > 0 && b == 0) || (a == 0 && b > 0)) {
      System.out.println("Existe un valor igual a 0");
    } else if ((a < 0 && b == 0) || (a == 0 && b < 0)) {
      System.out.println("Existe un valor igual a 0 y otro negativo");
    } else {
      if (a % b == 0) {
        System.out.println("El número " + a + " es divisible por " + b);
      } else {
        System.out.println("El número " + a + " no es divisible por " + b);
      }
    }
   
  }

}
