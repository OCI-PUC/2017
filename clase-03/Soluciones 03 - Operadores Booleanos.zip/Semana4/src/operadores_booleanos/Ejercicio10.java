package operadores_booleanos;

import java.util.Scanner;

public class Ejercicio10 {

  public static void main(String[] args) {
    // Muy largo?
    // Tranquile, aprenderemos a hacer esto de forma mucho más eficiente :) 
    
    Scanner scan = new Scanner(System.in);
    
    System.out.println("== Ingredientes ==");
    System.out.println("1. Queso");
    System.out.println("2. Tomate");
    System.out.println("3. Aceituna");
    System.out.println("4. Jamón");
    System.out.println("5. Pepperoni");
    System.out.println("6. Champiñones");
    System.out.println("Ingresar ingredientes:");
    
    int a = scan.nextInt();
    int b = scan.nextInt();
    int c = scan.nextInt();
    
    if (a < 1 || a > 6 || b < 1 || b > 6 || c < 1 || c > 6) {
      System.out.println("error");
    } else {
      int queso = 0;
      int tomate = 0;
      int aceituna = 0;
      int jamon = 0;
      int pepperoni = 0;
      int champiñones = 0;
      
      String ingrediente1 = "";
      if (a == 1)      { queso       = queso + 1;       ingrediente1 = "Queso"; }
      else if (a == 2) { tomate      = tomate + 1;      ingrediente1 = "Tomate"; }
      else if (a == 3) { aceituna    = aceituna + 1;    ingrediente1 = "Aceituna"; }
      else if (a == 4) { jamon       = jamon + 1;       ingrediente1 = "Jamón"; }
      else if (a == 5) { pepperoni   = pepperoni + 1;   ingrediente1 = "Pepperoni"; }
      else if (a == 6) { champiñones = champiñones + 1; ingrediente1 = "Champiñones"; }
      
      String ingrediente2 = "";
      if (b == 1)      { queso       = queso + 1;       ingrediente2 = "Queso"; }
      else if (b == 2) { tomate      = tomate + 1;      ingrediente2 = "Tomate"; }
      else if (b == 3) { aceituna    = aceituna + 1;    ingrediente2 = "Aceituna"; }
      else if (b == 4) { jamon       = jamon + 1;       ingrediente2 = "Jamón"; }
      else if (b == 5) { pepperoni   = pepperoni + 1;   ingrediente2 = "Pepperoni"; }
      else if (b == 6) { champiñones = champiñones + 1; ingrediente2 = "Champiñones"; }
      
      String ingrediente3 = "";
      if (c == 1)      { queso       = queso + 1;       ingrediente3 = "Queso"; }
      else if (c == 2) { tomate      = tomate + 1;      ingrediente3 = "Tomate"; }
      else if (c == 3) { aceituna    = aceituna + 1;    ingrediente3 = "Aceituna"; }
      else if (c == 4) { jamon       = jamon + 1;       ingrediente3 = "Jamón"; }
      else if (c == 5) { pepperoni   = pepperoni + 1;   ingrediente3 = "Pepperoni"; }
      else if (c == 6) { champiñones = champiñones + 1; ingrediente3 = "Champiñones"; }
      
      String prefijo;
      if (queso > 0 && tomate > 0) {
        prefijo = "Pizza Clásica ";
      } else {
        prefijo = "Pizza ";
      }
      
      String cuerpo;
      if ((queso > 0) && (tomate > 0) && (aceituna > 0 || jamon > 0)) {
        cuerpo = "Napolitana ";
      } else if (jamon > 0 && pepperoni > 0) {
        cuerpo = "Carnívora ";
      } else if ((queso > 0 || aceituna > 0) && tomate > 0 && champiñones > 0) {
        cuerpo = "Vegetariana ";
      } else {
        cuerpo = "Especial de la Casa ";
      }
      
      String sufijo = "";
      if (queso == 2) {
        if (tomate == 1)      {sufijo = "Doble Queso con Tomate"; }
        if (aceituna == 1)    {sufijo = "Doble Queso con Aceituna"; }
        if (jamon == 1)       {sufijo = "Doble Queso con Jamon"; }
        if (pepperoni == 1)   {sufijo = "Doble Queso con Pepperoni"; }
        if (champiñones == 1) {sufijo = "Doble Queso con Champiñones"; }
      } else if (tomate == 2) {
        if (queso == 1)       {sufijo = "2xTomate con Queso"; }
        if (aceituna == 1)    {sufijo = "2xTomate con Aceituna"; }
        if (jamon == 1)       {sufijo = "2xTomate con Jamon"; }
        if (pepperoni == 1)   {sufijo = "2xTomate con Pepperoni"; }
        if (champiñones == 1) {sufijo = "2xTomate con Champiñones"; }
      } else if (jamon == 2) {
        if (queso == 1)       {sufijo = "2xJamón con Queso"; }
        if (tomate == 1)      {sufijo = "2xJamón con Tomate"; }
        if (aceituna == 1)    {sufijo = "2xJamón con Aceituna"; }
        if (pepperoni == 1)   {sufijo = "2xJamón con Pepperoni"; }
        if (champiñones == 1) {sufijo = "2xJamón con Champiñones"; }
      } else if (pepperoni == 2) {
        if (queso == 1)       {sufijo = "2xPepperoni con Queso"; }
        if (tomate == 1)      {sufijo = "2xPepperoni con Tomate"; }
        if (jamon == 1)       {sufijo = "2xPepperoni con Jamón"; }
        if (aceituna == 1)    {sufijo = "2xPepperoni con Aceituna"; }
        if (champiñones == 1) {sufijo = "2xPepperoni con Champiñones"; }
      } else if (aceituna == 2) {
        if (queso == 1)       {sufijo = "2xAceituna con Queso"; }
        if (tomate == 1)      {sufijo = "2xAceituna con Tomate"; }
        if (jamon == 1)       {sufijo = "2xAceituna con Jamón"; }
        if (pepperoni == 1)   {sufijo = "2xAceituna con Pepperoni"; }
        if (champiñones == 1) {sufijo = "2xAceituna con Champiñones"; }
      } else if (champiñones == 2) {
        if (queso == 1)       {sufijo = "2xChampiñón con Queso"; }
        if (tomate == 1)      {sufijo = "2xChampiñón con Tomate"; }
        if (jamon == 1)       {sufijo = "2xChampiñón con Jamón"; }
        if (aceituna == 1)    {sufijo = "2xChampiñón con Aceituna"; }
        if (pepperoni == 1)   {sufijo = "2xChampiñón con Pepperoni"; }
      } else if (queso == 3) {
        sufijo = "Triple Queso";
      } else if (tomate == 3) {
        sufijo = "Big Special Tomate Deluxe";
      } else if (aceituna == 3) {
        sufijo = "Big Special Aceituna Deluxe";
      } else if (jamon == 3) {
        sufijo = "Big Special Jamon Deluxe";
      } else if (pepperoni == 3) {
        sufijo = "Big Special Pepperoni Deluxe";
      } else if (champiñones == 3) {
        sufijo = "Big Special Champiñones Deluxe";
      } else {
        sufijo = "- " + ingrediente1 + ", " + ingrediente2 + ", " + ingrediente3;
      }
      
      System.out.println(prefijo + cuerpo + sufijo);
    }    
    
  }

}
