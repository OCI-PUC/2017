package operadores_booleanos;

import java.util.Scanner;

public class Ejercicio08 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    int a = scan.nextInt();
    int b = scan.nextInt();
    int c = scan.nextInt();
    
    if (a + b > c && a + c > b && b + c > a) {
      if (a == b && b == c) {
        System.out.println("Es posible construir un triángulo equilátero");
      } else if (a == b || b == c || a == c) {
        System.out.println("Es posible construir un triángulo isóceles");
      } else {
        System.out.println("Es posible construir un triángulo escaleno");
      }
    } else {
      System.out.println("No es posible construir un triángulo");
    }

  }

}
