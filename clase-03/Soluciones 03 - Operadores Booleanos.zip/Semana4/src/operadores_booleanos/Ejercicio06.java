package operadores_booleanos;

import java.util.Scanner;

public class Ejercicio06 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    double nota = scan.nextDouble();
    
    if (nota < 1.0 || nota > 7.0) {
      System.out.println("Calificación no válida");
    } else if (1.0 <= nota && nota < 4.0) {
      System.out.println("Insuficiente");
    } else if (nota < 5.0) {
      System.out.println("Regular");
    } else if (nota < 6.0) {
      System.out.println("Suficiente");
    } else if (nota < 7.0) {
      System.out.println("Muy bien");
    } else if (nota == 7.0) {
      System.out.println("Excelente");
    }

  }

}
