package operadores_booleanos;

import java.util.Scanner;

public class Ejercicio04 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    System.out.println("Desea hamburguesa?");
    String hamburguesa = scan.nextLine();
    
    System.out.println("Lleva papas?");
    String papas = scan.nextLine();
    
    System.out.println("Lleva bebida?");
    String bebida = scan.nextLine();
    
    int valor_hamburguesa = 3000;
    int valor_papas = 1000;
    int valor_bebida = 1000;
    
    // Total
    int total = 0;
    if (hamburguesa.equals("sí")) {
      total = total + valor_hamburguesa;
    }
    
    if (papas.equals("sí")) {
      total = total + valor_papas;
    }
    
    if (bebida.equals("sí")) {
      total = total + valor_bebida;
    }
    
    // Descuento
    if (hamburguesa.equals("sí") && papas.equals("sí") && bebida.equals("sí")) {
      total = total * 90 / 100;
    } else if ((hamburguesa.equals("sí") && papas.equals("sí")) || (hamburguesa.equals("sí") && bebida.equals("sí"))) {
      total = total * 95 / 100;
    }

    // Mostrar mensaje
    System.out.println("El total es: $" + total);
  }

}
