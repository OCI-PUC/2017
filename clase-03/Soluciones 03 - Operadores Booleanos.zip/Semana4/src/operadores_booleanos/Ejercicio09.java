package operadores_booleanos;

import java.util.Scanner;

public class Ejercicio09 {

  public static void main(String[] args) {
    // La idea es simplemente revisar que los intervalos de
    // ambas coordenadas deben coincidir.
    
    Scanner scan = new Scanner(System.in);
    
    System.out.println("Mario[x, y, ancho, alto]:");
    int rect1_x = scan.nextInt();
    int rect1_y = scan.nextInt();
    int rect1_w = scan.nextInt();
    int rect1_h = scan.nextInt();
    
    System.out.println("Enemigo[x, y, ancho, alto]:");
    int rect2_x = scan.nextInt();
    int rect2_y = scan.nextInt();
    int rect2_w = scan.nextInt();
    int rect2_h = scan.nextInt();
    
    if (rect1_x - rect1_w / 2 < rect2_x + rect2_w / 2 &&
        rect1_x + rect1_w / 2 > rect2_x - rect2_w / 2 &&
        rect1_y - rect1_h / 2 < rect2_y + rect2_h / 2 && 
        rect1_y + rect1_h / 2 > rect2_y - rect2_h / 2) {
      System.out.println("Mario muere");
    } else {
      System.out.println("Mario está a salvo");
    }
  }

}
