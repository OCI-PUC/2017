package operadores_booleanos;

import java.util.Scanner;

public class Ejercicio03 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    System.out.println("Edad de constanza:");
    int edad = scan.nextInt();
    
    System.out.println("Viaja con adulto?");
    scan.nextLine();
    String adulto = scan.nextLine();
    
    System.out.println("Tiene carnet de identidad?");
    String carnet = scan.nextLine();
    
    System.out.println("Tiene antecedentes policiales?");
    String antecedentes = scan.nextLine();
    
    if ((edad > 18 || adulto.equals("sí")) && carnet.equals("sí") && antecedentes.equals("no"))  {
      System.out.println("¡Puede viajar!");
    } else {
      System.out.println("No puede viajar :c");
    }
    
  }

}
