package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio04 {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    int valor_dolar = 665;
    int dolares = scan.nextInt();
    
    int total = valor_dolar * dolares;
    
    System.out.println(total);
  }
}
