package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio08 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int a = scan.nextInt();
    
    System.out.println("1 x " + a + " = " + (a));
    System.out.println("2 x " + a + " = " + (2 * a));
    System.out.println("3 x " + a + " = " + (3 * a));
    System.out.println("4 x " + a + " = " + (4 * a));
    System.out.println("5 x " + a + " = " + (5 * a));
    System.out.println("6 x " + a + " = " + (6 * a));
    System.out.println("7 x " + a + " = " + (7 * a));
    System.out.println("8 x " + a + " = " + (8 * a));
    System.out.println("9 x " + a + " = " + (9 * a));
    System.out.println("10 x " + a + " = " + (10 * a));
  }

}
