package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio02 {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int a = scan.nextInt();
    int b = scan.nextInt();
    int c = scan.nextInt();
    int d = (a + b) * c; // Recuerda escribir el *
    
    System.out.println(d);
    // Notemos que esto hubiese sido equivalente a 
    // System.out.println((a + b) * c;);
  }
}
