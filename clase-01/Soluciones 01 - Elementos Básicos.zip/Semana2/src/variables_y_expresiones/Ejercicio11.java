package variables_y_expresiones;

public class Ejercicio11 {

  public static void main(String[] args) {
    int anterior_anterior = 0;
    int anterior = 1;
    int actual = anterior + anterior_anterior;
    System.out.println(anterior_anterior);
    System.out.println(anterior);
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);

    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
    
    anterior_anterior = anterior;
    anterior = actual;
    actual = anterior + anterior_anterior;
    System.out.println(actual);
  }

}
