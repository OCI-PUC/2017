package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio03 {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    int año_actual = 2017;
    int año_consulta = scan.nextInt();
    
    int diferencia = año_actual - año_consulta;
    
    System.out.println(diferencia);
  }
}
