package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio10 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    System.out.println("Ingresar altura:");
    double altura = scan.nextDouble();
    
    System.out.println("Ingresar radio basal:");
    double radio = scan.nextDouble();
    
    double volumen_cilindro = Math.PI * altura * (radio * radio);

    System.out.println("Ingresar lado para la base de la pirámide");
    double lado = scan.nextDouble();
    
    double volumen_piramide = altura * (lado * lado) / 3;
    
    double diferencia = Math.abs(volumen_piramide - volumen_cilindro);
    
    System.out.println("volumen cilindro: " + volumen_cilindro);
    System.out.println("Volumen piramide: " + volumen_piramide);
    System.out.println("diferencia: " + diferencia);
  }

}
