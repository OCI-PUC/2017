package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio06 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    // Necesitamos double porque vamos a trabajar con decimales
    double a = scan.nextDouble();
    double resultado = Math.round(a);
    
    System.out.println(resultado);
  }

}
