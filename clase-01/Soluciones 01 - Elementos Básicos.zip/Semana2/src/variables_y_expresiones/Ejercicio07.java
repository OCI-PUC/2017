package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio07 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int valor_pan = 128;
    
    System.out.println("PepeBot: ¿Cúantos panes desea llevar?");
    int panes = scan.nextInt();
    int costo = valor_pan * panes;
    
    System.out.println("PepeBot: Son " + costo + " pesos.");
    System.out.println("PepeBot: ¿Con cuánto va a pagar?");
    
    int pago = scan.nextInt();
    int vuelto = pago - costo;
    
    System.out.println("PepeBot: su vuelto son " + vuelto + " pesos");
  }

}
