package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio05 {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    int horas_por_dia = 24;
    int horas_por_semana = 7 * horas_por_dia;
    int horas_por_mes = horas_por_semana * 4;
    
    int meses = scan.nextInt();
    int horas = meses * horas_por_mes;
    
    System.out.println(meses + " meses son " + horas + " horas");
  }
}
