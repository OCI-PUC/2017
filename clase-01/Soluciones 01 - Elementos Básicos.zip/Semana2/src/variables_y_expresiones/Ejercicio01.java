package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio01 {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int a = scan.nextInt();
    int b = scan.nextInt();
    int c = a + b;
    
    System.out.println(c);
    // Notemos que esto hubiese sido equivalente a 
    // System.out.println(a+b);
  }
}
