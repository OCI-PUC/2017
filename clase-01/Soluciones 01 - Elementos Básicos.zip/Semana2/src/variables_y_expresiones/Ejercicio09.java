package variables_y_expresiones;

import java.util.Scanner;

public class Ejercicio09 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    double a = scan.nextDouble();
    double b = scan.nextDouble();
    double c = scan.nextDouble();
    
    double media = (a + b + c) / 3;
    double varianza = ((a - media) * (a - media) + (b - media) * (b - media) + (c - media) * (c - media)) / 2;
    
    System.out.println("media: " + media);
    System.out.println("varianza: " + varianza);
  }
}
