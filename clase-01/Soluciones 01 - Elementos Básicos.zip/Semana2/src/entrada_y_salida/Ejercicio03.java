package entrada_y_salida;
import java.util.Scanner;

public class Ejercicio03 {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    String nombre = scan.nextLine();
    System.out.println("Hola " + nombre + "!");
  }
}
