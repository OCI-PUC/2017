package entrada_y_salida;

public class Ejercicio02 {

  public static void main(String[] args) {
    System.out.println("OOOOO CCCCC IIIII");
    System.out.println("O   O C       I  ");
    System.out.println("O   O C       I  ");
    System.out.println("O   O C       I  ");
    System.out.println("OOOOO CCCCC IIIII");
  }

}
