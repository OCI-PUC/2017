package entrada_y_salida;
import java.util.Scanner;

public class Ejercicio04 {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    String nombre = scan.nextLine();
    
    int edad = scan.nextInt();
    
    System.out.println("Hola " + nombre + "! tienes " + edad + " años");
  }
}
