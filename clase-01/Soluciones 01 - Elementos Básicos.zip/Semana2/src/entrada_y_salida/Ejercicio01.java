package entrada_y_salida;

public class Ejercicio01 {

  public static void main(String[] args) {
    System.out.println("Hola mundo!");
  }

}
