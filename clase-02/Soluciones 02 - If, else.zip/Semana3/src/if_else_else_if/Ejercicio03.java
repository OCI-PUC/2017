package if_else_else_if;

import java.util.Scanner;

public class Ejercicio03 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int a = scan.nextInt();
    int b = scan.nextInt(); 
    
    if (a == b) {
      System.out.println("Son iguales :D");
    } else {
      System.out.println("Son diferentes :(");
    }
  }

}
