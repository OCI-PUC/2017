package if_else_else_if;

import java.util.Scanner;

public class Ejercicio07 {
  public static void main(String[] args) {
    System.out.println("¿Contraseña?");
  
    Scanner scan = new Scanner(System.in);
    String contraseña = scan.nextLine();
    
    if (contraseña.equals("aycaramba")) {
      System.out.println("puedes entrar");
    } else {
      System.out.println("contraseña incorrecta");
    }

  }
}
