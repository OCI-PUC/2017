package if_else_else_if;

import java.util.Scanner;

public class Ejercicio06 {

  public static void main(String[] args) {
    System.out.println("Ingrese su edad:");
    Scanner scan = new Scanner(System.in);
    int numero = scan.nextInt();
    
    if (numero < 0) {
      System.out.println("error");
    } else if (numero < 18) {
      System.out.println("menor de edad");
    } else {
      System.out.println("mayor de edad");
    }

  }
}
