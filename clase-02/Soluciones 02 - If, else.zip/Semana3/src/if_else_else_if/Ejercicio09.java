package if_else_else_if;

import java.util.Scanner;

public class Ejercicio09 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    System.out.println("Ingrese el valor de a:");
    int a = scan.nextInt();
    
    System.out.println("Ingrese el valor de b:");
    int b = scan.nextInt();
    
    System.out.println("Ingrese una operación:");
    System.out.println("1. Sumar");
    System.out.println("2. Multiplicar");
    int opcion = scan.nextInt();
    
    if (opcion == 1) {
      System.out.println("El resultado es " + (a + b));
    } else if (opcion == 2) {
      System.out.println("El resultado es " + (a * b));
    } else {
      System.out.println("Esta opción no existe :x");
    }

  }

}
