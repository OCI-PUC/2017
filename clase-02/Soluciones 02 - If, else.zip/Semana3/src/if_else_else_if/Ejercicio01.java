package if_else_else_if;

import java.util.Scanner;

public class Ejercicio01 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int numero = scan.nextInt();
    
    if(numero == 10) {
      System.out.println("Hola!");
    }
  }

}
