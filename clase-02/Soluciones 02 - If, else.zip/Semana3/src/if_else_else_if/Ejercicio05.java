package if_else_else_if;

import java.util.Scanner;

public class Ejercicio05 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int numero = scan.nextInt();
    
    if (numero >= 0) {
      System.out.println(numero);
    } else {
      System.out.println(-numero);
    }

    // El valor absoluto se puede calcular con:
    //   Math.abs(numero)
    // Aunque esto era trampa para el ejercicio :3
  }
}
