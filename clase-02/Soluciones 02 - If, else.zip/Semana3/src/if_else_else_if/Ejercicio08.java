package if_else_else_if;

import java.util.Scanner;

public class Ejercicio08 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    String tipo = scan.nextLine();
    int saldo = scan.nextInt();
    
    if (tipo.equals("a")) {
      if (saldo >= 640) {
        int nuevo_saldo = saldo - 640;
        System.out.println("SALDO " + nuevo_saldo);
      } else {
        System.out.println("SALDO INSUFICIENTE");
      }
    } else if (tipo.equals("e")) {
      if (saldo >= 210) {
        int nuevo_saldo = saldo - 210;
        System.out.println("SALDO " + nuevo_saldo);
      } else {
        System.out.println("SALDO INSUFICIENTE");
      }
    }
      
  }

}
