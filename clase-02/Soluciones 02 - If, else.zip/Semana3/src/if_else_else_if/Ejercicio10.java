package if_else_else_if;

import java.util.Scanner;

public class Ejercicio10 {

  public static void main(String[] args) {
    System.out.println("¿Qué desea comprar?");
    System.out.println("1. Poción");
    System.out.println("2. Pokeball");
    System.out.println("3. Superpoción");
    System.out.println("4. Superball");
    System.out.println("5. Nada");

    Scanner scan = new Scanner(System.in);
    int opcion = scan.nextInt();
    
    // En lugar de anidar cada caso particular, podemos guardar el nombre
    // de lo que se va a comprar y su precio en variables externas!
    
    String cosa = "";
    int valor = 0;
    
    if (opcion == 1) {
      cosa = "pociones";
      valor = 300;
    } else if (opcion == 2) {
      cosa = "pokeballs";
      valor = 200;
    } else if (opcion == 3) {
      cosa = "superpociones";
      valor = 700;
    } else if (opcion == 4) {
      cosa = "superballs";
      valor = 600;
    }
    
    if (opcion > 0) {
      if (opcion < 5) {
        System.out.println("¿Cuántas unidades de " + cosa + " desea llevar?");
        int unidades = scan.nextInt();
        if (unidades > 0) {
          int costo = unidades * valor;
          System.out.println(unidades + " unidades de " + cosa + " cuestan " + costo);
          
          System.out.println("¿Desea confirmar la compra?");
          System.out.println("1. Sí");
          System.out.println("2. No");
          int opcion2 = scan.nextInt();
          if (opcion2 == 1) {
            System.out.println("Su pedido está listo para ser retirado");
          } else if (opcion2 == 2) {
            System.out.println("Su pedido ha sido cancelado");
          } else {
            System.out.println("...?");
          }
        } else {
          System.out.println("...?");
        }
      } else if (opcion == 5) {
          // no hacemos nada :p
      } else {
        System.out.println("...?");
      }
    } else {
      System.out.println("...?");
    }
    
    
    System.out.println("¡Hasta luego!");
  }

}
