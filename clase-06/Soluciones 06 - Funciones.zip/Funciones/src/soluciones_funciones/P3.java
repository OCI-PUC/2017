package soluciones_funciones;

import java.util.Scanner;

public class P3 {

	public static int factorial(int n) {
		int r = 1;
		for (int i = 2; i <= n; i++) {
			r *= i;
		}
		return r;
	}
	
	public static int combinatoria(int A, int t) {
		return factorial(A) / (factorial(t) * factorial(A - t));
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int A = sc.nextInt();
		int t = sc.nextInt();
		sc.close();

		System.out.println(combinatoria(A,t));
	}

}
