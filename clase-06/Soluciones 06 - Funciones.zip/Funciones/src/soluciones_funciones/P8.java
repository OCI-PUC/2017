package soluciones_funciones;

import java.util.Scanner;

public class P8 {

	public static boolean es_divisor(int n, int i) {
		return n % i == 0;
	}

	public static int numero_divisores(int n) {
		int r = 0;
		for (int i = 1; i <= n; i++) {
			if (es_divisor(n, i)) {
				r += 1;
			}
		}
		return r;
	}

	public static boolean es_rsa(int n) {
		return numero_divisores(n) == 4;
	}

	public static int cantidad_numeros_rsa(int a, int b) {
		int r = 0;
		for (int i = a; i <= b; i++) {
			if (es_rsa(i)) {
				r += 1;
			}
		}
		return r;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese el l�mite inferior del rango");
		int a = sc.nextInt();
		System.out.println("Ingrese el l�mite superior del rango");
		int b = sc.nextInt();
		sc.close();

		int n = cantidad_numeros_rsa(a, b);
		System.out.println("La cantidad de n�meros RSA entre " + a + " y " + b + " es " + n);
	}

}
