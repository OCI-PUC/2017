package soluciones_funciones;

import java.util.Scanner;

public class P5 {

	public static double distancia(double x1, double y1, double x2, double y2) {
		double deltax = x1 - x2;
		double deltay = y1 - y2;
		return Math.sqrt(deltax * deltax + deltay * deltay);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		double total = 0.0;

		double x0 = sc.nextDouble();
		double y0 = sc.nextDouble();

		double x1 = x0;
		double y1 = y0;

		for (int i = 0; i < n - 1; i++) {
			double x2 = sc.nextDouble();
			double y2 = sc.nextDouble();
			total += distancia(x1, y1, x2, y2);
			x1 = x2;
			y1 = y2;
		}

		total += distancia(x1, y1, x0, y0);

		System.out.println(total);

		sc.close();
	}

}
