package soluciones_funciones;

import java.util.Scanner;

public class P6 {

	public static boolean ascendente(int a, int b, int c) {
		return a < b && b < c;
	}

	public static boolean descendente(int a, int b, int c) {
		return a > b && b > c;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		sc.close();

		if (ascendente(a, b, c)) {
			System.out.println("Pez ascendente");
		} else if (descendente(a, b, c)) {
			System.out.println("Pez descendente");
		} else {
			System.out.println("Pez no encontrado");
		}
	}

}
