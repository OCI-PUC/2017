package soluciones_funciones;

import java.util.Scanner;

public class P2 {

	public static boolean es_divisor(int n, int i) {
		return n % i == 0;
	}

	public static int suma_divisores(int n) {
		int suma = 0;
		for (int i = 1; i < n; i++) {
			if (es_divisor(n, i)) {
				suma += i;
			}
		}
		return suma;
	}

	public static boolean son_amigos(int a, int b) {
		return suma_divisores(a) == b && suma_divisores(b) == a;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		sc.close();

		if (son_amigos(a, b)) {
			System.out.println("Son n�meros amigos!");
		} else {
			System.out.println("No son n�meros amigos");
		}
	}

}
