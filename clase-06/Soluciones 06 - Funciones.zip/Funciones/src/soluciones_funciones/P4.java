package soluciones_funciones;

import java.util.Scanner;

public class P4 {

	public static int dar_vuelta(int n) {
		int r = 0;
		while (n > 0) {
			r *= 10;
			r += n % 10;
			n /= 10;
		}
		return r;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.close();

		System.out.println(dar_vuelta(n));
	}

}
