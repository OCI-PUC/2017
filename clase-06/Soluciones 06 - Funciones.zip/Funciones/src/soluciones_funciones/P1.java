package soluciones_funciones;

import java.util.Scanner;

public class P1 {

	public static int suma(int a, int b) {
		return a + b;
	}

	public static int resta(int a, int b) {
		return a - b;
	}

	public static int multiplicacion(int a, int b) {
		return a * b;
	}
	
	public static double division(int a, int b) {
		return (double) a / b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		sc.close();

		if (c == 1) {
			System.out.println(suma(a, b));
		} else if (c == 2) {
			System.out.println(resta(a, b));
		} else if (c == 3) {
			System.out.println(multiplicacion(a, b));
		} else if (c == 4) {
			System.out.println(division(a, b));
		} else {
			System.out.println("Operacion no es valida");
		}
	}

}
