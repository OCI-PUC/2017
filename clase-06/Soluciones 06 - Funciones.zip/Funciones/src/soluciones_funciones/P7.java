package soluciones_funciones;

import java.util.Scanner;

public class P7 {

	public static int planA(int a, int b, int c) {
		int r = 15 * b + 20 * c;
		if (a > 100) {
			r += (a - 100) * 25;
		}
		return r;
	}

	public static int planB(int a, int b, int c) {
		int r = 35 * b + 25 * c;
		if (a > 250) {
			r += (a - 250) * 45;
		}
		return r;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("�N�mero de minutos a hablar en la madrugada?");
		int a = sc.nextInt();
		System.out.println("�N�mero de minutos a hablar en la tarde?");
		int b = sc.nextInt();
		System.out.println("�N�mero de minutos a hablar en el fin de semana?");
		int c = sc.nextInt();
		sc.close();

		int costoA = planA(a, b, c);
		int costoB = planB(a, b, c);

		System.out.println("El plan A cuesta " + costoA);
		System.out.println("El plan B cuesta " + costoB);

		if (costoA < costoB) {
			System.out.println("El plan A es el m�s barato.");
		} else if (costoB < costoA) {
			System.out.println("El plan B es el m�s barato.");
		} else {
			System.out.println("El plan A y el B cuestan lo mismo.");
		}

	}

}
